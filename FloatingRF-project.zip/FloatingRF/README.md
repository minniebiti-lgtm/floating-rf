# Floating RF

Android floating assistant (Kotlin, Dark Graphite Premium). minSdk 26, targetSdk 34, compileSdk 35.

## Build

Butuh: JDK 17, Android SDK (platform 35, build-tools), akses ke Google Maven & Maven Central.

```bash
echo "sdk.dir=/path/to/Android/Sdk" > local.properties
gradle wrapper --gradle-version 8.9   # sekali saja, membuat gradlew
./gradlew assembleRelease             # APK: app/build/outputs/apk/release/
```

Release di-sign dengan debug key agar bisa langsung dipasang. Ganti dengan keystore sendiri sebelum dipublikasikan.

## Struktur

- `FloatingService` : foreground service pemilik bubble + panel AI Menu (WindowManager overlay)
- `Panels.kt` : Home, Calculator, Battery, Clock, OCR, Settings (panel)
- `CalculatorEngine` : parser ekspresi (unit-check lulus, lihat catatan)
- `CaptureActivity` + `ScreenshotService` : OCR dari satu tangkapan layar (persetujuan sistem MediaProjection) atau gambar pilihan
- `MainActivity` : Settings lengkap + status izin

## Mode Hide

Bubble di-set `alpha = 0` tetapi tetap terpasang di WindowManager dengan ukuran/posisi yang sama,
sehingga area sentuh tidak berubah dan tap langsung membuka AI Menu. Bubble tidak pernah dimunculkan
kembali oleh tap; hanya dimatikan lewat toggle di Settings atau tombol Mode Hide di AI Menu.

## Status verifikasi

- `CalculatorEngine.kt` dikompilasi dengan Kotlin 2.0.21 dan lulus 12 dari 12 pengecekan logika.
- XML resource lolos pengecekan well-formed.
- **Gradle build belum dijalankan**: environment pembuatan tidak punya Android SDK dan tidak ada akses ke Maven repo. APK belum ada dan belum diuji di perangkat.
