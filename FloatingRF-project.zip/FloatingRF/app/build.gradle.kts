plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.floatingrf.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.floatingrf.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            // Release di-sign dengan debug key supaya APK bisa langsung dipasang.
            // Ganti dengan keystore sendiri sebelum dipublikasikan.
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    // ML Kit Text Recognition (model ter-bundle, Latin)
    implementation("com.google.mlkit:text-recognition:16.0.1")
}
