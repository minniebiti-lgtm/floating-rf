package com.floatingrf.app

import android.Manifest
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

/** Halaman Settings utama: toggle bubble/hide, tampilan, ukuran, versi, status izin. */
class MainActivity : AppCompatActivity() {

    private lateinit var bubbleSwitch: Switch
    private lateinit var hideSwitch: Switch
    private lateinit var permOverlay: TextView
    private lateinit var permNotif: TextView
    private var syncing = false

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> syncFromPrefs() }

    private val notifLauncher =
        registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.RequestPermission()) {
            refreshPermissions()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    override fun onResume() {
        super.onResume()
        Prefs.of(this).registerOnSharedPreferenceChangeListener(prefListener)
        refreshPermissions()
        syncFromPrefs()
    }

    override fun onPause() {
        Prefs.of(this).unregisterOnSharedPreferenceChangeListener(prefListener)
        super.onPause()
    }

    private fun buildUi() {
        val pad = Ui.dp(this, 20)
        val root = Ui.vbox(this).apply { setPadding(pad, pad * 2, pad, pad) }

        root.addView(Ui.text(this, "Floating RF", 30f, R.color.rf_ice, bold = true))
        root.addView(Ui.text(this, "Dark Graphite floating assistant", 14f, R.color.rf_text_dim))
        root.addView(Ui.spacer(this, 20))

        // --- Toggle utama
        bubbleSwitch = Switch(this).apply {
            text = "Floating Bubble"
            textSize = 17f
            setTextColor(Ui.color(this@MainActivity, R.color.rf_text))
            setOnCheckedChangeListener { _, on -> if (!syncing) onBubbleToggled(on) }
        }
        hideSwitch = Switch(this).apply {
            text = "Mode Hide"
            textSize = 17f
            setTextColor(Ui.color(this@MainActivity, R.color.rf_text))
            setOnCheckedChangeListener { _, on -> if (!syncing) Prefs.setHideMode(this@MainActivity, on) }
        }
        root.addView(bubbleSwitch, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 8, this))
        root.addView(hideSwitch, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 8, this))
        root.addView(Ui.spacer(this, 12))

        // --- Tampilan
        root.addView(Ui.text(this, "Tampilan", 18f, R.color.rf_ice, bold = true))
        val sizeLabel = Ui.text(this, "", 14f, R.color.rf_text_dim)
        val sizeBar = SeekBar(this).apply {
            max = Prefs.SIZE_MAX - Prefs.SIZE_MIN
            progress = Prefs.sizeDp(this@MainActivity) - Prefs.SIZE_MIN
        }
        sizeLabel.text = "Ukuran bubble: ${Prefs.sizeDp(this)} dp"
        sizeBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                val v = Prefs.SIZE_MIN + p
                sizeLabel.text = "Ukuran bubble: $v dp"
                if (fromUser) Prefs.setSizeDp(this@MainActivity, v)
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {}
        })
        root.addView(sizeLabel, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 4, this))
        root.addView(sizeBar, Ui.lp(Ui.MATCH, Ui.WRAP))

        val opLabel = Ui.text(this, "", 14f, R.color.rf_text_dim)
        val opBar = SeekBar(this).apply {
            max = 70
            progress = Prefs.opacity(this@MainActivity) - 30
        }
        opLabel.text = "Transparansi bubble: ${Prefs.opacity(this)}%"
        opBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                val v = 30 + p
                opLabel.text = "Transparansi bubble: $v%"
                if (fromUser) Prefs.setOpacity(this@MainActivity, v)
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {}
        })
        root.addView(opLabel, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 4, this))
        root.addView(opBar, Ui.lp(Ui.MATCH, Ui.WRAP))
        root.addView(Ui.spacer(this, 16))

        // --- Izin
        root.addView(Ui.text(this, "Izin", 18f, R.color.rf_ice, bold = true))
        permOverlay = Ui.text(this, "", 15f)
        permNotif = Ui.text(this, "", 15f)
        root.addView(permOverlay, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 4, this))
        root.addView(
            Ui.button(this, "Buka izin Overlay", sizeSp = 14f) {
                startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                )
            }, Ui.lp(Ui.MATCH, Ui.dp(this, 46), 0f, 4, this)
        )
        root.addView(permNotif, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 4, this))
        root.addView(
            Ui.button(this, "Minta izin Notifikasi", sizeSp = 14f) { requestNotificationPermission() },
            Ui.lp(Ui.MATCH, Ui.dp(this, 46), 0f, 4, this)
        )
        root.addView(Ui.spacer(this, 16))

        // --- Versi
        val versionName = try {
            packageManager.getPackageInfo(packageName, 0).versionName
        } catch (e: Exception) { "-" }
        root.addView(Ui.text(this, "Floating RF v$versionName", 13f, R.color.rf_text_dim).apply {
            gravity = Gravity.CENTER
        }, Ui.lp(Ui.MATCH, Ui.WRAP))

        setContentView(ScrollView(this).apply {
            setBackgroundColor(Ui.color(this@MainActivity, R.color.rf_black))
            isFillViewport = true
            addView(root)
        })
    }

    private fun onBubbleToggled(on: Boolean) {
        if (on) {
            if (!Settings.canDrawOverlays(this)) {
                setSwitch(bubbleSwitch, false)
                Toast.makeText(this, "Izinkan overlay terlebih dahulu", Toast.LENGTH_LONG).show()
                startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                )
                return
            }
            if (Build.VERSION.SDK_INT >= 33 && !hasNotifPermission()) requestNotificationPermission()
            Prefs.setBubbleEnabled(this, true)
            FloatingService.start(this)
        } else {
            Prefs.setBubbleEnabled(this, false)
            FloatingService.stop(this)
        }
    }

    private fun hasNotifPermission() =
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && !hasNotifPermission()) {
            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            Toast.makeText(this, "Izin notifikasi sudah diberikan", Toast.LENGTH_SHORT).show()
        }
    }

    private fun refreshPermissions() {
        val overlay = Settings.canDrawOverlays(this)
        permOverlay.text = "Overlay: " + if (overlay) "diizinkan ✓" else "belum diizinkan ✗"
        permNotif.text = "Notifikasi: " + if (hasNotifPermission()) "diizinkan ✓" else "belum diizinkan ✗"
    }

    private fun syncFromPrefs() {
        setSwitch(bubbleSwitch, Prefs.bubbleEnabled(this))
        setSwitch(hideSwitch, Prefs.hideMode(this))
    }

    private fun setSwitch(s: Switch, v: Boolean) {
        syncing = true
        s.isChecked = v
        syncing = false
    }
}
