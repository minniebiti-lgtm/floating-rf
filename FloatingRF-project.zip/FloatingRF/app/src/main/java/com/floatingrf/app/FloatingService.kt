package com.floatingrf.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat

/**
 * Foreground service pemilik seluruh overlay: bubble dan panel AI Menu (keduanya via WindowManager).
 */
class FloatingService : Service(), PanelHost, OcrBridge.Listener {

    private lateinit var wm: WindowManager
    private lateinit var uiCtx: Context

    private var bubble: FrameLayout? = null
    private var bubbleParams: WindowManager.LayoutParams? = null

    private var menuRoot: MenuRoot? = null
    private var menuParams: WindowManager.LayoutParams? = null
    private var body: FrameLayout? = null
    private var titleView: TextView? = null
    private var backBtn: TextView? = null
    private var currentPanel: Panel? = null

    private var capturing = false

    private lateinit var home: HomePanel
    private lateinit var ocrPanel: OcrPanel
    private lateinit var calcPanel: CalculatorPanel
    private lateinit var batteryPanel: BatteryPanel
    private lateinit var clockPanel: ClockPanel
    private lateinit var settingsPanel: SettingsPanel

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        when (key) {
            Prefs.KEY_BUBBLE_ENABLED -> if (!Prefs.bubbleEnabled(this)) stopSelf()
            Prefs.KEY_SIZE_DP -> applyBubbleSize()
            Prefs.KEY_OPACITY, Prefs.KEY_HIDE_MODE -> applyBubbleAlpha()
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        uiCtx = ContextThemeWrapper(this, R.style.Theme_FloatingRF)

        ocrPanel = OcrPanel(uiCtx, this)
        calcPanel = CalculatorPanel(uiCtx, this)
        batteryPanel = BatteryPanel(uiCtx, this)
        clockPanel = ClockPanel(uiCtx, this)
        settingsPanel = SettingsPanel(uiCtx, this)
        home = HomePanel(uiCtx, this, { ocrPanel }, { calcPanel }, { batteryPanel }, { clockPanel }, { settingsPanel })

        OcrBridge.listener = this
        Prefs.of(this).registerOnSharedPreferenceChangeListener(prefListener)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            Prefs.setBubbleEnabled(this, false)
            stopSelf()
            return START_NOT_STICKY
        }
        startAsForeground()
        if (!Settings.canDrawOverlays(this)) {
            Prefs.setBubbleEnabled(this, false)
            stopSelf()
            return START_NOT_STICKY
        }
        if (bubble == null) addBubble()
        return START_STICKY
    }

    override fun onDestroy() {
        OcrBridge.listener = null
        Prefs.of(this).unregisterOnSharedPreferenceChangeListener(prefListener)
        removeMenu()
        removeBubble()
        super.onDestroy()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        clampBubble()
    }

    // ------------------------------------------------------------------ foreground notification

    private fun startAsForeground() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, getString(R.string.notif_channel), NotificationManager.IMPORTANCE_LOW)
            )
        }
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, FloatingService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n: Notification = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(getString(R.string.notif_title))
            .setContentText(getString(R.string.notif_text))
            .setContentIntent(open)
            .addAction(0, "Matikan", stop)
            .setOngoing(true)
            .build()
        val type = if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
        ServiceCompat.startForeground(this, NOTIF_ID, n, type)
    }

    // ------------------------------------------------------------------ bubble

    @Suppress("DEPRECATION")
    private fun overlayType(): Int =
        if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE

    private fun screenW() = resources.displayMetrics.widthPixels
    private fun screenH() = resources.displayMetrics.heightPixels

    private fun addBubble() {
        val size = Ui.dp(this, Prefs.sizeDp(this))
        val frame = FrameLayout(uiCtx).apply {
            setBackgroundResource(R.drawable.bg_bubble)
            val pad = size / 6
            addView(ImageView(uiCtx).apply {
                setImageResource(R.drawable.ic_launcher)
                scaleType = ImageView.ScaleType.FIT_CENTER
                setPadding(pad, pad, pad, pad)
            }, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        }
        val lp = WindowManager.LayoutParams(
            size, size, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = Prefs.posX(this@FloatingService)
            y = Prefs.posY(this@FloatingService)
        }
        bubbleParams = lp
        bubble = frame
        attachBubbleTouch(frame, lp)
        wm.addView(frame, lp)
        clampBubble()
        applyBubbleAlpha()
    }

    private fun attachBubbleTouch(v: View, lp: WindowManager.LayoutParams) {
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0; var dragging = false
        v.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY; startX = lp.x; startY = lp.y; dragging = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX; val dy = e.rawY - downY
                    if (!dragging && (kotlin.math.abs(dx) > slop || kotlin.math.abs(dy) > slop)) dragging = true
                    if (dragging) {
                        lp.x = startX + dx.toInt()
                        lp.y = startY + dy.toInt()
                        clampBubble()
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (dragging) Prefs.setPos(this, lp.x, lp.y) else openMenu()
                    true
                }
                MotionEvent.ACTION_CANCEL -> {
                    if (dragging) Prefs.setPos(this, lp.x, lp.y)
                    true
                }
                else -> false
            }
        }
    }

    private fun clampBubble() {
        val b = bubble ?: return
        val lp = bubbleParams ?: return
        lp.x = lp.x.coerceIn(0, (screenW() - lp.width).coerceAtLeast(0))
        lp.y = lp.y.coerceIn(0, (screenH() - lp.height).coerceAtLeast(0))
        try { wm.updateViewLayout(b, lp) } catch (_: IllegalArgumentException) {}
    }

    private fun applyBubbleSize() {
        val b = bubble ?: return
        val lp = bubbleParams ?: return
        val size = Ui.dp(this, Prefs.sizeDp(this))
        lp.width = size; lp.height = size
        (b.getChildAt(0) as? ImageView)?.let { val p = size / 6; it.setPadding(p, p, p, p) }
        clampBubble()
    }

    /**
     * Mode Hide: bubble 100% transparan (alpha 0) tetapi tetap terpasang di WindowManager dengan
     * ukuran & posisi sama, sehingga area sentuh tidak berubah dan tap tetap membuka AI Menu.
     */
    private fun applyBubbleAlpha() {
        val b = bubble ?: return
        b.alpha = when {
            capturing -> 0f
            Prefs.hideMode(this) -> 0f
            else -> Prefs.opacity(this) / 100f
        }
    }

    private fun removeBubble() {
        bubble?.let { try { wm.removeView(it) } catch (_: IllegalArgumentException) {} }
        bubble = null
        bubbleParams = null
    }

    // ------------------------------------------------------------------ AI Menu overlay

    /** Root layar penuh: scrim + kartu panel. Menangani tombol Back saat window focusable. */
    private inner class MenuRoot(c: Context) : FrameLayout(c) {
        override fun dispatchKeyEvent(event: KeyEvent): Boolean {
            if (event.keyCode == KeyEvent.KEYCODE_BACK && event.action == KeyEvent.ACTION_UP) {
                if (currentPanel === home) closeMenu() else goHome()
                return true
            }
            return super.dispatchKeyEvent(event)
        }
    }

    private fun openMenu() {
        if (menuRoot != null) return
        val root = MenuRoot(uiCtx).apply {
            setBackgroundColor(0x99000000.toInt())
            setOnClickListener { closeMenu() } // tap di luar kartu menutup menu
        }

        val card = LinearLayout(uiCtx).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.bg_panel)
            val p = Ui.dp(uiCtx, 14)
            setPadding(p, p, p, p)
            isClickable = true // konsumsi tap agar tidak menutup menu
            elevation = Ui.dp(uiCtx, 12).toFloat()
        }

        val back = Ui.text(uiCtx, "‹", 26f, R.color.rf_ice, bold = true).apply {
            setPadding(Ui.dp(uiCtx, 6), 0, Ui.dp(uiCtx, 14), 0)
            setOnClickListener { goHome() }
        }
        val title = Ui.text(uiCtx, "", 17f, R.color.rf_text, bold = true)
        val close = Ui.text(uiCtx, "✕", 18f, R.color.rf_text_dim).apply {
            setPadding(Ui.dp(uiCtx, 14), 0, Ui.dp(uiCtx, 6), 0)
            setOnClickListener { closeMenu() }
        }
        val header = Ui.hbox(uiCtx).apply {
            addView(back)
            addView(title, Ui.lp(0, Ui.WRAP, 1f))
            addView(close)
        }
        card.addView(header, Ui.lp(Ui.MATCH, Ui.WRAP))
        card.addView(Ui.spacer(uiCtx, 8))

        val bodyFrame = FrameLayout(uiCtx)
        val scroll = ScrollView(uiCtx).apply {
            isFillViewport = false
            addView(bodyFrame)
        }
        card.addView(scroll, Ui.lp(Ui.MATCH, Ui.WRAP))

        val cardW = minOf((screenW() * 0.92f).toInt(), Ui.dp(uiCtx, 380))
        root.addView(card, FrameLayout.LayoutParams(cardW, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.CENTER))

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE }

        menuRoot = root; menuParams = lp; body = bodyFrame; titleView = title; backBtn = back
        wm.addView(root, lp)
        showPanel(home)
    }

    private fun showPanel(p: Panel) {
        currentPanel?.onHide()
        currentPanel = p
        val b = body ?: return
        b.removeAllViews()
        b.addView(p.view())
        titleView?.text = p.title
        backBtn?.visibility = if (p === home) View.GONE else View.VISIBLE
        setFocusable(p.needsFocus)
        p.onShow()
    }

    /** OCR butuh fokus (EditText/seleksi); panel lain tidak, agar tidak mengganggu aplikasi di bawah. */
    private fun setFocusable(focusable: Boolean) {
        val root = menuRoot ?: return
        val lp = menuParams ?: return
        lp.flags = if (focusable) lp.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
        else lp.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        try { wm.updateViewLayout(root, lp) } catch (_: IllegalArgumentException) {}
    }

    private fun removeMenu() {
        currentPanel?.onHide()
        currentPanel = null
        menuRoot?.let { try { wm.removeView(it) } catch (_: IllegalArgumentException) {} }
        menuRoot = null; menuParams = null; body = null; titleView = null; backBtn = null
    }

    // ------------------------------------------------------------------ PanelHost

    override fun navigate(panel: Panel) = showPanel(panel)
    override fun goHome() = showPanel(home)
    override fun closeMenu() = removeMenu()

    override fun openSettingsScreen() {
        removeMenu()
        startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    override fun requestOcr(mode: String) {
        // Tutup overlay & sembunyikan bubble sementara agar tidak ikut tertangkap layar.
        capturing = true
        removeMenu()
        applyBubbleAlpha()
        startActivity(
            Intent(this, CaptureActivity::class.java)
                .putExtra(CaptureActivity.EXTRA_MODE, mode)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }

    // ------------------------------------------------------------------ OcrBridge.Listener

    override fun onCaptureStarted() { /* overlay sudah disembunyikan oleh requestOcr */ }

    override fun onOcrResult(text: String) {
        capturing = false
        applyBubbleAlpha()
        openMenu()
        showPanel(ocrPanel)
        ocrPanel.setResult(text)
    }

    override fun onOcrError(message: String) {
        capturing = false
        applyBubbleAlpha()
        openMenu()
        showPanel(ocrPanel)
        ocrPanel.setStatus(message)
    }

    companion object {
        const val ACTION_STOP = "com.floatingrf.app.STOP"
        private const val CHANNEL = "floating_rf_service"
        private const val NOTIF_ID = 4201

        fun start(ctx: Context) {
            androidx.core.content.ContextCompat.startForegroundService(
                ctx, Intent(ctx, FloatingService::class.java)
            )
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, FloatingService::class.java))
        }
    }
}
