package com.floatingrf.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.os.BatteryManager
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Kontrak antara panel dan FloatingService. */
interface PanelHost {
    fun navigate(panel: Panel)
    fun goHome()
    fun closeMenu()
    fun requestOcr(mode: String)
    fun openSettingsScreen()
}

abstract class Panel(protected val ctx: Context, protected val host: PanelHost) {
    abstract val title: String
    /** True bila panel butuh input/seleksi teks (jendela dibuat focusable). */
    open val needsFocus: Boolean = false
    abstract fun view(): View
    open fun onShow() {}
    open fun onHide() {}

    protected fun grid(vararg buttons: View): LinearLayout {
        val box = Ui.vbox(ctx)
        buttons.toList().chunked(2).forEach { row ->
            val h = Ui.hbox(ctx)
            row.forEach { b ->
                h.addView(b, Ui.lp(0, Ui.dp(ctx, 64), 1f, 4, ctx))
            }
            box.addView(h, Ui.lp(Ui.MATCH, Ui.WRAP))
        }
        return box
    }
}

// ---------------------------------------------------------------------------------------------
// HOME (AI Menu)
// ---------------------------------------------------------------------------------------------
class HomePanel(
    ctx: Context, host: PanelHost,
    private val ocr: () -> Panel, private val calc: () -> Panel,
    private val battery: () -> Panel, private val clock: () -> Panel,
    private val settings: () -> Panel
) : Panel(ctx, host) {
    override val title = "AI Menu"
    private lateinit var hideBtn: android.widget.Button

    override fun view(): View {
        val root = Ui.vbox(ctx)
        hideBtn = Ui.button(ctx, hideLabel(), sizeSp = 14f) {
            Prefs.setHideMode(ctx, !Prefs.hideMode(ctx))
            hideBtn.text = hideLabel()
        }
        root.addView(
            grid(
                Ui.button(ctx, "OCR / Scanner") { host.navigate(ocr()) },
                Ui.button(ctx, "Calculator") { host.navigate(calc()) },
                Ui.button(ctx, "Battery") { host.navigate(battery()) },
                Ui.button(ctx, "Clock") { host.navigate(clock()) },
                Ui.button(ctx, "Settings") { host.navigate(settings()) },
                hideBtn
            )
        )
        root.addView(
            Ui.button(ctx, "Close", accent = true) { host.closeMenu() },
            Ui.lp(Ui.MATCH, Ui.dp(ctx, 48), 0f, 4, ctx)
        )
        return root
    }

    override fun onShow() {
        if (::hideBtn.isInitialized) hideBtn.text = hideLabel()
    }

    private fun hideLabel() = if (Prefs.hideMode(ctx)) "Mode Hide: ON" else "Mode Hide: OFF"
}

// ---------------------------------------------------------------------------------------------
// CALCULATOR
// ---------------------------------------------------------------------------------------------
class CalculatorPanel(ctx: Context, host: PanelHost) : Panel(ctx, host) {
    override val title = "Calculator"
    private val engine = CalculatorEngine()
    private lateinit var exprView: TextView
    private lateinit var resultView: TextView

    override fun view(): View {
        val root = Ui.vbox(ctx)

        exprView = Ui.text(ctx, "", 16f, R.color.rf_text_dim).apply {
            gravity = Gravity.END
            maxLines = 2
        }
        resultView = Ui.text(ctx, "0", 34f, R.color.rf_ice, bold = true).apply {
            gravity = Gravity.END
            maxLines = 1
        }
        root.addView(exprView, Ui.lp(Ui.MATCH, Ui.WRAP))
        root.addView(resultView, Ui.lp(Ui.MATCH, Ui.WRAP))
        root.addView(Ui.spacer(ctx, 8))

        val rows = listOf(
            listOf("C", "⌫", "%", "÷"),
            listOf("7", "8", "9", "×"),
            listOf("4", "5", "6", "-"),
            listOf("1", "2", "3", "+"),
            listOf("0", ".", "=")
        )
        rows.forEach { row ->
            val h = Ui.hbox(ctx)
            row.forEach { key ->
                val accent = key == "="
                val b = Ui.button(ctx, key, accent = accent, sizeSp = 20f) { press(key) }
                val weight = if (key == "0") 2f else 1f
                h.addView(b, Ui.lp(0, Ui.dp(ctx, 48), weight, 3, ctx))
            }
            root.addView(h, Ui.lp(Ui.MATCH, Ui.WRAP))
        }
        refresh()
        return root
    }

    private fun press(k: String) {
        when (k) {
            "C" -> engine.clear()
            "⌫" -> engine.backspace()
            "%" -> engine.inputPercent()
            "÷", "×", "-", "+" -> engine.inputOperator(k[0])
            "." -> engine.inputDot()
            "=" -> engine.equals()
            else -> engine.inputDigit(k[0])
        }
        refresh()
    }

    private fun refresh() {
        exprView.text = engine.expression
        resultView.text = engine.result.ifEmpty { "0" }
    }
}

// ---------------------------------------------------------------------------------------------
// BATTERY
// ---------------------------------------------------------------------------------------------
class BatteryIconView(ctx: Context) : View(ctx) {
    var level: Int = 0
        set(v) { field = v.coerceIn(0, 100); invalidate() }
    var charging: Boolean = false
        set(v) { field = v; invalidate() }

    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = Ui.dp(ctx, 3).toFloat()
        color = Ui.color(ctx, R.color.rf_ice)
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val ctxRef = ctx

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val tip = w * 0.08f
        val body = RectF(stroke.strokeWidth, stroke.strokeWidth, w - tip - stroke.strokeWidth, h - stroke.strokeWidth)
        c.drawRoundRect(body, 14f, 14f, stroke)
        c.drawRoundRect(RectF(w - tip, h * 0.35f, w, h * 0.65f), 6f, 6f, fill.apply {
            color = Ui.color(ctxRef, R.color.rf_ice)
        })
        fill.color = when {
            charging -> Ui.color(ctxRef, R.color.rf_ok)
            level <= 15 -> Ui.color(ctxRef, R.color.rf_danger)
            else -> Ui.color(ctxRef, R.color.rf_ice)
        }
        val pad = stroke.strokeWidth * 2.2f
        val inner = RectF(pad, pad, pad + (body.width() - pad * 1.2f) * level / 100f, h - pad)
        if (level > 0) c.drawRoundRect(inner, 8f, 8f, fill)
    }
}

class BatteryPanel(ctx: Context, host: PanelHost) : Panel(ctx, host) {
    override val title = "Battery Informer"
    private lateinit var icon: BatteryIconView
    private lateinit var pct: TextView
    private lateinit var status: TextView
    private lateinit var source: TextView
    private var registered = false

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) = render(i)
    }

    override fun view(): View {
        val root = Ui.vbox(ctx).apply { gravity = Gravity.CENTER_HORIZONTAL }
        icon = BatteryIconView(ctx)
        pct = Ui.text(ctx, "--%", 40f, R.color.rf_ice, bold = true).apply { gravity = Gravity.CENTER }
        status = Ui.text(ctx, "", 16f).apply { gravity = Gravity.CENTER }
        source = Ui.text(ctx, "", 13f, R.color.rf_text_dim).apply { gravity = Gravity.CENTER }
        root.addView(icon, Ui.lp(Ui.dp(ctx, 140), Ui.dp(ctx, 70), 0f, 8, ctx))
        root.addView(pct, Ui.lp(Ui.MATCH, Ui.WRAP))
        root.addView(status, Ui.lp(Ui.MATCH, Ui.WRAP))
        root.addView(source, Ui.lp(Ui.MATCH, Ui.WRAP))
        return root
    }

    override fun onShow() {
        if (registered) return
        // ACTION_BATTERY_CHANGED adalah sticky: registerReceiver langsung mengembalikan nilai terkini.
        val sticky = ContextCompat.registerReceiver(
            ctx, receiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
        registered = true
        if (sticky != null) render(sticky)
    }

    override fun onHide() {
        if (!registered) return
        try { ctx.unregisterReceiver(receiver) } catch (_: IllegalArgumentException) {}
        registered = false
    }

    private fun render(i: Intent) {
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        val p = if (level >= 0 && scale > 0) level * 100 / scale else 0
        val st = i.getIntExtra(BatteryManager.EXTRA_STATUS, BatteryManager.BATTERY_STATUS_UNKNOWN)
        val plugged = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0)

        val statusText = when (st) {
            BatteryManager.BATTERY_STATUS_CHARGING -> "Charging"
            BatteryManager.BATTERY_STATUS_FULL -> "Full"
            BatteryManager.BATTERY_STATUS_DISCHARGING,
            BatteryManager.BATTERY_STATUS_NOT_CHARGING -> "Discharging"
            else -> "Unknown"
        }
        val src = when {
            plugged and BatteryManager.BATTERY_PLUGGED_AC != 0 -> "Sumber: AC"
            plugged and BatteryManager.BATTERY_PLUGGED_USB != 0 -> "Sumber: USB"
            plugged and BatteryManager.BATTERY_PLUGGED_WIRELESS != 0 -> "Sumber: Wireless"
            else -> "Sumber: baterai"
        }
        icon.charging = st == BatteryManager.BATTERY_STATUS_CHARGING
        icon.level = p
        pct.text = "$p%"
        status.text = statusText
        source.text = src
    }
}

// ---------------------------------------------------------------------------------------------
// CLOCK
// ---------------------------------------------------------------------------------------------
class ClockPanel(ctx: Context, host: PanelHost) : Panel(ctx, host) {
    override val title = "Digital Clock"
    private lateinit var time: TextView
    private lateinit var date: TextView
    private var registered = false

    // ACTION_TIME_TICK dikirim sistem tiap menit: tanpa loop/polling, hemat CPU.
    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) = update()
    }

    override fun view(): View {
        val root = Ui.vbox(ctx).apply { gravity = Gravity.CENTER_HORIZONTAL }
        time = Ui.text(ctx, "--:--", 56f, R.color.rf_ice, bold = true).apply { gravity = Gravity.CENTER }
        date = Ui.text(ctx, "", 15f, R.color.rf_text_dim).apply { gravity = Gravity.CENTER }
        root.addView(time, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 10, ctx))
        root.addView(date, Ui.lp(Ui.MATCH, Ui.WRAP))
        update()
        return root
    }

    override fun onShow() {
        if (registered) return
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_TIME_TICK)
            addAction(Intent.ACTION_TIME_CHANGED)
            addAction(Intent.ACTION_TIMEZONE_CHANGED)
        }
        ContextCompat.registerReceiver(ctx, receiver, f, ContextCompat.RECEIVER_NOT_EXPORTED)
        registered = true
        update()
    }

    override fun onHide() {
        if (!registered) return
        try { ctx.unregisterReceiver(receiver) } catch (_: IllegalArgumentException) {}
        registered = false
    }

    private fun update() {
        if (!::time.isInitialized) return
        val now = Date()
        // SimpleDateFormat dibuat ulang agar mengikuti zona waktu perangkat saat ini.
        time.text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(now)
        date.text = SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(now)
    }
}

// ---------------------------------------------------------------------------------------------
// OCR
// ---------------------------------------------------------------------------------------------
class OcrPanel(ctx: Context, host: PanelHost) : Panel(ctx, host) {
    override val title = "OCR / Text Scanner"
    override val needsFocus = true
    private lateinit var input: EditText
    private lateinit var status: TextView
    private var pendingText: String? = null
    private var pendingStatus: String = "Pilih sumber: tangkapan layar atau gambar."

    override fun view(): View {
        val root = Ui.vbox(ctx)
        status = Ui.text(ctx, pendingStatus, 13f, R.color.rf_text_dim)
        input = EditText(ctx).apply {
            setTextColor(Ui.color(ctx, R.color.rf_text))
            setHintTextColor(Ui.color(ctx, R.color.rf_text_dim))
            hint = "Hasil OCR muncul di sini"
            textSize = 14f
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            gravity = Gravity.TOP or Gravity.START
            minLines = 5
            maxLines = 9
            setBackgroundResource(R.drawable.bg_button)
            setPadding(Ui.dp(ctx, 10), Ui.dp(ctx, 10), Ui.dp(ctx, 10), Ui.dp(ctx, 10))
            setText(pendingText ?: "")
        }

        root.addView(
            Ui.hbox(ctx).apply {
                addView(Ui.button(ctx, "Scan Layar", accent = true, sizeSp = 14f) {
                    host.requestOcr(CaptureActivity.MODE_SCREEN)
                }, Ui.lp(0, Ui.dp(ctx, 44), 1f, 3, ctx))
                addView(Ui.button(ctx, "Pilih Gambar", sizeSp = 14f) {
                    host.requestOcr(CaptureActivity.MODE_IMAGE)
                }, Ui.lp(0, Ui.dp(ctx, 44), 1f, 3, ctx))
            }, Ui.lp(Ui.MATCH, Ui.WRAP)
        )
        root.addView(status, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 4, ctx))
        root.addView(input, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 3, ctx))
        root.addView(
            Ui.hbox(ctx).apply {
                addView(Ui.button(ctx, "Copy", sizeSp = 14f) { copy() }, Ui.lp(0, Ui.dp(ctx, 44), 1f, 3, ctx))
                addView(Ui.button(ctx, "Search", sizeSp = 14f) { search() }, Ui.lp(0, Ui.dp(ctx, 44), 1f, 3, ctx))
                addView(Ui.button(ctx, "Clear", sizeSp = 14f) {
                    input.setText(""); setStatus("Dibersihkan.")
                }, Ui.lp(0, Ui.dp(ctx, 44), 1f, 3, ctx))
            }, Ui.lp(Ui.MATCH, Ui.WRAP)
        )
        return root
    }

    override fun onHide() {
        // Simpan isi editor agar tidak hilang saat berpindah panel.
        if (::input.isInitialized) pendingText = input.text.toString()
    }

    fun setResult(text: String) {
        pendingText = text
        if (::input.isInitialized) input.setText(text)
        setStatus("Selesai. Pilih sebagian teks untuk dicari, atau cari semuanya.")
    }

    fun setStatus(msg: String) {
        pendingStatus = msg
        if (::status.isInitialized) status.text = msg
    }

    private fun currentText(): String = if (::input.isInitialized) input.text.toString() else ""

    /** Teks terpilih; bila tidak ada seleksi, seluruh teks. */
    private fun selectedOrAll(): String {
        val t = currentText()
        val s = input.selectionStart; val e = input.selectionEnd
        return if (s in 0 until e && e <= t.length) t.substring(s, e) else t
    }

    private fun copy() {
        val t = selectedOrAll().trim()
        if (t.isEmpty()) { Toast.makeText(ctx, "Tidak ada teks untuk disalin", Toast.LENGTH_SHORT).show(); return }
        val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
        cm.setPrimaryClip(android.content.ClipData.newPlainText("Floating RF OCR", t))
        Toast.makeText(ctx, "Teks disalin", Toast.LENGTH_SHORT).show()
    }

    private fun search() {
        val t = selectedOrAll().trim()
        if (t.isEmpty()) { Toast.makeText(ctx, "Tidak ada teks untuk dicari", Toast.LENGTH_SHORT).show(); return }
        val q = java.net.URLEncoder.encode(t.take(300), "UTF-8")
        val i = Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://www.google.com/search?q=$q"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            ctx.startActivity(i)
            host.closeMenu()
        } catch (e: Exception) {
            Toast.makeText(ctx, "Tidak ada browser yang tersedia", Toast.LENGTH_SHORT).show()
        }
    }
}

// ---------------------------------------------------------------------------------------------
// SETTINGS (di dalam AI Menu)
// ---------------------------------------------------------------------------------------------
class SettingsPanel(ctx: Context, host: PanelHost) : Panel(ctx, host) {
    override val title = "Settings"
    private lateinit var hideSwitch: Switch

    override fun view(): View {
        val root = Ui.vbox(ctx)

        hideSwitch = Switch(ctx).apply {
            text = "Mode Hide"
            setTextColor(Ui.color(ctx, R.color.rf_text))
            isChecked = Prefs.hideMode(ctx)
            setOnCheckedChangeListener { _, on -> Prefs.setHideMode(ctx, on) }
        }
        root.addView(hideSwitch, Ui.lp(Ui.MATCH, Ui.WRAP, 0f, 4, ctx))

        root.addView(Ui.text(ctx, "Ukuran bubble", 13f, R.color.rf_text_dim))
        root.addView(SeekBar(ctx).apply {
            max = Prefs.SIZE_MAX - Prefs.SIZE_MIN
            progress = Prefs.sizeDp(ctx) - Prefs.SIZE_MIN
            setOnSeekBarChangeListener(simpleListener { Prefs.setSizeDp(ctx, Prefs.SIZE_MIN + it) })
        }, Ui.lp(Ui.MATCH, Ui.WRAP))

        root.addView(Ui.text(ctx, "Transparansi bubble", 13f, R.color.rf_text_dim))
        root.addView(SeekBar(ctx).apply {
            max = 70
            progress = Prefs.opacity(ctx) - 30
            setOnSeekBarChangeListener(simpleListener { Prefs.setOpacity(ctx, 30 + it) })
        }, Ui.lp(Ui.MATCH, Ui.WRAP))

        root.addView(Ui.spacer(ctx, 8))
        root.addView(
            Ui.button(ctx, "Pengaturan lengkap", sizeSp = 14f) { host.openSettingsScreen() },
            Ui.lp(Ui.MATCH, Ui.dp(ctx, 44))
        )
        return root
    }

    override fun onShow() {
        if (::hideSwitch.isInitialized) hideSwitch.isChecked = Prefs.hideMode(ctx)
    }

    private fun simpleListener(onChange: (Int) -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) { if (fromUser) onChange(p) }
        override fun onStartTrackingTouch(sb: SeekBar) {}
        override fun onStopTrackingTouch(sb: SeekBar) {}
    }
}
