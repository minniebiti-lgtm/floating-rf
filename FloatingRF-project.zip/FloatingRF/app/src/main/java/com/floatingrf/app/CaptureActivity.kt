package com.floatingrf.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.mlkit.vision.common.InputImage

/**
 * Activity transparan. Dua mode:
 *  - MODE_SCREEN: meminta persetujuan sistem MediaProjection, lalu menyerahkan ke ScreenshotService
 *    (hanya mengambil SATU tangkapan layar, bukan perekaman).
 *  - MODE_IMAGE: membuka pemilih gambar sistem, lalu OCR pada gambar yang dipilih.
 */
class CaptureActivity : AppCompatActivity() {

    private val projectionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
            if (res.resultCode == Activity.RESULT_OK && res.data != null) {
                val svc = Intent(this, ScreenshotService::class.java).apply {
                    putExtra(ScreenshotService.EXTRA_CODE, res.resultCode)
                    putExtra(ScreenshotService.EXTRA_DATA, res.data)
                }
                OcrBridge.started()
                androidx.core.content.ContextCompat.startForegroundService(this, svc)
            } else {
                OcrBridge.error("Izin tangkapan layar ditolak.")
            }
            finish()
        }

    private val pickLauncher =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            if (uri == null) {
                OcrBridge.error("Tidak ada gambar dipilih.")
            } else {
                try {
                    OcrBridge.started()
                    OcrBridge.recognize(InputImage.fromFilePath(this, uri))
                } catch (e: Exception) {
                    OcrBridge.error("Gagal membuka gambar: ${e.message}")
                }
            }
            finish()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (savedInstanceState != null) return // launcher sudah dijalankan sebelumnya
        when (intent.getStringExtra(EXTRA_MODE)) {
            MODE_IMAGE -> pickLauncher.launch("image/*")
            else -> {
                val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                projectionLauncher.launch(mpm.createScreenCaptureIntent())
            }
        }
    }

    companion object {
        const val EXTRA_MODE = "mode"
        const val MODE_SCREEN = "screen"
        const val MODE_IMAGE = "image"
    }
}
