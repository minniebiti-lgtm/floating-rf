package com.floatingrf.app

import android.graphics.Bitmap
import android.os.Handler
import android.os.Looper
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

/**
 * Jembatan in-process antara CaptureActivity / ScreenshotService dan panel OCR di FloatingService.
 * Semua callback dipanggil di main thread.
 */
object OcrBridge {
    interface Listener {
        fun onCaptureStarted()
        fun onOcrResult(text: String)
        fun onOcrError(message: String)
    }

    @Volatile
    var listener: Listener? = null

    private val main = Handler(Looper.getMainLooper())

    fun started() = main.post { listener?.onCaptureStarted() }
    fun result(text: String) = main.post { listener?.onOcrResult(text) }
    fun error(msg: String) = main.post { listener?.onOcrError(msg) }

    /** Jalankan ML Kit pada Bitmap, lalu kirim hasil ke listener. */
    fun recognize(bitmap: Bitmap) = recognize(InputImage.fromBitmap(bitmap, 0))

    fun recognize(image: InputImage) {
        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        recognizer.process(image)
            .addOnSuccessListener { visionText ->
                val t = visionText.text.trim()
                if (t.isEmpty()) error("Tidak ada teks yang terdeteksi.") else result(t)
            }
            .addOnFailureListener { e ->
                error("OCR gagal: ${e.message ?: "kesalahan tidak diketahui"}")
            }
            .addOnCompleteListener { recognizer.close() }
    }
}
