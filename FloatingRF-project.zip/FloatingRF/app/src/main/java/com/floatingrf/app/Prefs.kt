package com.floatingrf.app

import android.content.Context
import android.content.SharedPreferences

/** Penyimpanan pengaturan ringan berbasis SharedPreferences. */
object Prefs {
    const val NAME = "floating_rf_prefs"
    const val KEY_BUBBLE_ENABLED = "bubble_enabled"
    const val KEY_HIDE_MODE = "hide_mode"
    const val KEY_SIZE_DP = "bubble_size_dp"
    const val KEY_OPACITY = "bubble_opacity" // 30..100 (persen)
    const val KEY_X = "bubble_x"
    const val KEY_Y = "bubble_y"

    const val SIZE_MIN = 40
    const val SIZE_MAX = 96
    const val SIZE_DEFAULT = 60

    fun of(ctx: Context): SharedPreferences =
        ctx.applicationContext.getSharedPreferences(NAME, Context.MODE_PRIVATE)

    fun bubbleEnabled(ctx: Context) = of(ctx).getBoolean(KEY_BUBBLE_ENABLED, false)
    fun hideMode(ctx: Context) = of(ctx).getBoolean(KEY_HIDE_MODE, false)
    fun sizeDp(ctx: Context) = of(ctx).getInt(KEY_SIZE_DP, SIZE_DEFAULT).coerceIn(SIZE_MIN, SIZE_MAX)
    fun opacity(ctx: Context) = of(ctx).getInt(KEY_OPACITY, 100).coerceIn(30, 100)
    fun posX(ctx: Context) = of(ctx).getInt(KEY_X, 24)
    fun posY(ctx: Context) = of(ctx).getInt(KEY_Y, 400)

    fun setBubbleEnabled(ctx: Context, v: Boolean) = of(ctx).edit().putBoolean(KEY_BUBBLE_ENABLED, v).apply()
    fun setHideMode(ctx: Context, v: Boolean) = of(ctx).edit().putBoolean(KEY_HIDE_MODE, v).apply()
    fun setSizeDp(ctx: Context, v: Int) = of(ctx).edit().putInt(KEY_SIZE_DP, v).apply()
    fun setOpacity(ctx: Context, v: Int) = of(ctx).edit().putInt(KEY_OPACITY, v).apply()
    fun setPos(ctx: Context, x: Int, y: Int) = of(ctx).edit().putInt(KEY_X, x).putInt(KEY_Y, y).apply()
}
