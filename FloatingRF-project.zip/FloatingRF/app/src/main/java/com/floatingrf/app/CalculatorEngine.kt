package com.floatingrf.app

import java.math.BigDecimal
import java.math.MathContext
import java.math.RoundingMode

/**
 * Mesin kalkulator: menyimpan ekspresi sebagai string dan mengevaluasinya dengan
 * recursive-descent parser (prioritas operator benar, persen sebagai postfix).
 */
class CalculatorEngine {
    var expression: String = ""
        private set
    var result: String = ""
        private set

    private var justEvaluated = false

    private val operators = setOf('+', '-', '×', '÷')

    fun inputDigit(d: Char) {
        if (justEvaluated) { expression = ""; justEvaluated = false }
        if (expression.isNotEmpty() && expression.last() == '%') return // angka setelah % tidak valid
        // cegah angka nol berlebih di depan: "00"
        val lastNum = lastNumber()
        if (lastNum == "0" && d == '0') return
        if (lastNum == "0" && d != '0') expression = expression.dropLast(1)
        expression += d
        updatePreview()
    }

    fun inputDot() {
        if (justEvaluated) { expression = ""; justEvaluated = false }
        val lastNum = lastNumber()
        if (lastNum.contains('.')) return
        if (lastNum.isEmpty()) expression += "0"
        expression += "."
        updatePreview()
    }

    fun inputOperator(op: Char) {
        if (justEvaluated) { justEvaluated = false } // lanjutkan dari hasil
        if (expression.isEmpty()) {
            if (op == '-') expression = "-"
            return
        }
        val last = expression.last()
        if (last in operators) {
            // ganti operator terakhir (kecuali ekspresi hanya "-")
            if (expression.length == 1) return
            expression = expression.dropLast(1) + op
        } else if (last == '.') {
            expression = expression.dropLast(1) + op
        } else {
            expression += op
        }
        updatePreview()
    }

    fun inputPercent() {
        if (expression.isEmpty()) return
        val last = expression.last()
        if (last.isDigit() || last == '%') {
            expression += "%"
            justEvaluated = false
            updatePreview()
        }
    }

    fun clear() {
        expression = ""
        result = ""
        justEvaluated = false
    }

    fun backspace() {
        if (justEvaluated) { clear(); return }
        if (expression.isNotEmpty()) expression = expression.dropLast(1)
        updatePreview()
    }

    fun equals() {
        // Buang operator/titik menggantung di akhir, mis. "5+" -> "5".
        while (expression.isNotEmpty() && (expression.last() in operators || expression.last() == '.')) {
            expression = expression.dropLast(1)
        }
        if (expression.isEmpty()) return
        val value = evaluate(expression)
        if (value == null) {
            result = "Error"
            return
        }
        result = format(value)
        expression = result
        justEvaluated = true
    }

    private fun lastNumber(): String {
        var i = expression.length
        while (i > 0 && (expression[i - 1].isDigit() || expression[i - 1] == '.')) i--
        return expression.substring(i)
    }

    private fun updatePreview() {
        result = if (expression.isEmpty()) "" else {
            val v = evaluate(expression)
            if (v == null) "" else format(v)
        }
    }

    // ---------- Evaluasi ----------

    private var pos = 0
    private lateinit var src: String

    private fun evaluate(expr: String): BigDecimal? {
        return try {
            src = expr
            pos = 0
            val v = parseExpr()
            if (pos != src.length) null else v
        } catch (e: ArithmeticException) {
            null
        } catch (e: IllegalStateException) {
            null
        }
    }

    private fun parseExpr(): BigDecimal {
        var v = parseTerm()
        while (pos < src.length && (src[pos] == '+' || src[pos] == '-')) {
            val op = src[pos++]
            val r = parseTerm()
            v = if (op == '+') v.add(r) else v.subtract(r)
        }
        return v
    }

    private fun parseTerm(): BigDecimal {
        var v = parseUnary()
        while (pos < src.length && (src[pos] == '×' || src[pos] == '÷')) {
            val op = src[pos++]
            val r = parseUnary()
            v = if (op == '×') v.multiply(r) else v.divide(r, MathContext(15, RoundingMode.HALF_UP))
        }
        return v
    }

    private fun parseUnary(): BigDecimal {
        if (pos < src.length && src[pos] == '-') {
            pos++
            return parseUnary().negate()
        }
        return parsePostfix()
    }

    private fun parsePostfix(): BigDecimal {
        var v = parseNumber()
        while (pos < src.length && src[pos] == '%') {
            pos++
            v = v.divide(BigDecimal(100))
        }
        return v
    }

    private fun parseNumber(): BigDecimal {
        val start = pos
        while (pos < src.length && (src[pos].isDigit() || src[pos] == '.')) pos++
        if (start == pos) error("angka diharapkan")
        return BigDecimal(src.substring(start, pos))
    }

    private fun format(v: BigDecimal): String {
        val rounded = v.round(MathContext(12, RoundingMode.HALF_UP))
        var s = rounded.stripTrailingZeros().toPlainString()
        if (s == "-0") s = "0"
        return s
    }
}
