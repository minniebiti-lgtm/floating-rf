package com.floatingrf.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat

/**
 * Mengambil SATU tangkapan layar setelah pengguna menyetujui dialog sistem, lalu berhenti.
 * Tidak ada perekaman video. Notifikasi foreground ditampilkan selama proses berlangsung.
 */
class ScreenshotService : Service() {

    private val main = Handler(Looper.getMainLooper())
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var finished = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) { stopSelf(); return START_NOT_STICKY }
        startAsForeground()

        val code = intent.getIntExtra(EXTRA_CODE, 0)
        @Suppress("DEPRECATION")
        val data: Intent? = intent.getParcelableExtra(EXTRA_DATA)
        if (data == null) {
            OcrBridge.error("Data izin tangkapan layar tidak valid.")
            shutdown()
            return START_NOT_STICKY
        }

        // Beri waktu agar dialog sistem hilang dan overlay kita tersembunyi sebelum menangkap.
        main.postDelayed({ capture(code, data) }, 450)
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "Tangkapan layar OCR", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val n: Notification = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setContentTitle("Floating RF")
            .setContentText("Mengambil tangkapan layar untuk OCR")
            .setOngoing(true)
            .build()
        val type = if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION else 0
        ServiceCompat.startForeground(this, NOTIF_ID, n, type)
    }

    private fun capture(code: Int, data: Intent) {
        try {
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val mp = mpm.getMediaProjection(code, data)
            projection = mp

            // Wajib di Android 14+: daftarkan callback sebelum membuat VirtualDisplay.
            mp.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { main.post { shutdown() } }
            }, main)

            val dm = resources.displayMetrics
            val w = dm.widthPixels
            val h = dm.heightPixels
            val ir = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
            reader = ir

            ir.setOnImageAvailableListener({ r ->
                if (finished) return@setOnImageAvailableListener
                val image = try { r.acquireLatestImage() } catch (e: Exception) { null }
                    ?: return@setOnImageAvailableListener
                finished = true
                try {
                    val plane = image.planes[0]
                    val rowPadding = plane.rowStride - plane.pixelStride * w
                    val bmp = Bitmap.createBitmap(
                        w + rowPadding / plane.pixelStride, h, Bitmap.Config.ARGB_8888
                    )
                    bmp.copyPixelsFromBuffer(plane.buffer)
                    val cropped = Bitmap.createBitmap(bmp, 0, 0, w, h)
                    if (cropped !== bmp) bmp.recycle()
                    OcrBridge.recognize(cropped)
                } catch (e: Exception) {
                    OcrBridge.error("Gagal memproses tangkapan layar: ${e.message}")
                } finally {
                    image.close()
                    main.post { shutdown() }
                }
            }, main)

            display = mp.createVirtualDisplay(
                "FloatingRF-OCR", w, h, dm.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                ir.surface, null, main
            )

            // Pengaman: jika tidak ada frame dalam 4 detik, berhenti dengan pesan error.
            main.postDelayed({
                if (!finished) {
                    finished = true
                    OcrBridge.error("Tangkapan layar timeout. Coba lagi.")
                    shutdown()
                }
            }, 4000)
        } catch (e: Exception) {
            OcrBridge.error("Tidak bisa mengambil layar: ${e.message}")
            shutdown()
        }
    }

    private fun shutdown() {
        main.removeCallbacksAndMessages(null)
        try { display?.release() } catch (_: Exception) {}
        try { reader?.close() } catch (_: Exception) {}
        try { projection?.stop() } catch (_: Exception) {}
        display = null; reader = null; projection = null
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        main.removeCallbacksAndMessages(null)
        try { display?.release() } catch (_: Exception) {}
        try { reader?.close() } catch (_: Exception) {}
        try { projection?.stop() } catch (_: Exception) {}
        super.onDestroy()
    }

    companion object {
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        private const val CHANNEL = "floating_rf_capture"
        private const val NOTIF_ID = 4202
    }
}
