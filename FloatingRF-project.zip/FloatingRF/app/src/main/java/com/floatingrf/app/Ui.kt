package com.floatingrf.app

import android.content.Context
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat

/** Helper kecil untuk membangun UI secara programatik dengan tema Dark Graphite. */
object Ui {
    fun dp(ctx: Context, v: Int): Int = (v * ctx.resources.displayMetrics.density).toInt()
    fun color(ctx: Context, id: Int): Int = ContextCompat.getColor(ctx, id)

    fun text(
        ctx: Context, s: String, sizeSp: Float = 14f,
        colorRes: Int = R.color.rf_text, bold: Boolean = false
    ): TextView = TextView(ctx).apply {
        text = s
        textSize = sizeSp
        setTextColor(color(ctx, colorRes))
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    fun button(
        ctx: Context, label: String, accent: Boolean = false, sizeSp: Float = 16f,
        onClick: () -> Unit
    ): Button = Button(ctx).apply {
        text = label
        textSize = sizeSp
        isAllCaps = false
        setTextColor(color(ctx, if (accent) R.color.rf_black else R.color.rf_text))
        setBackgroundResource(if (accent) R.drawable.bg_button_accent else R.drawable.bg_button)
        stateListAnimator = null
        minHeight = 0
        minimumHeight = 0
        setOnClickListener { onClick() }
    }

    fun vbox(ctx: Context): LinearLayout = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
    }

    fun hbox(ctx: Context): LinearLayout = LinearLayout(ctx).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
    }

    fun lp(w: Int, h: Int, weight: Float = 0f, margin: Int = 0, ctx: Context? = null): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(w, h, weight)
        if (margin != 0 && ctx != null) {
            val m = dp(ctx, margin)
            p.setMargins(m, m, m, m)
        }
        return p
    }

    val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    fun spacer(ctx: Context, heightDp: Int): View = View(ctx).apply {
        layoutParams = LinearLayout.LayoutParams(MATCH, dp(ctx, heightDp))
    }
}
